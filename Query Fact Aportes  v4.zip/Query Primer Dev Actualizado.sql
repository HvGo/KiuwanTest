--QUERY DEL PRIMER DEVENGUE DE OBLIGACION
 
SELECT       
       e.ruc,
       ac.cuspp,
       ac.codcuenta,
       c.tiporigencuenta,  
       c.tipformulario, 
       c.mesdevengueinicial,    
       ac.mesdevengue,
       ac.fecpago,
       ac.fecacreditacion,
       ac.tipaporte,
       ac.tipfondo,
       ac.tipmovimiento,       
       case 
         when ac.mesdevengue = c.mesdevengueinicial then 1        
       end AS PRIMER_DEV
FROM udwhods.ud_acreditacioncic ac left join md_empleador e on ac.codempleador = e.codempleador
                                   left join md_destipoaporte ta on ac.tipaporte = ta.tipaporte,
     md_cuenta c 
WHERE ac.codtransaccion IN ('1A01','1A50') AND --APORTE, REZAGO LOP_TRANSACCIONMOVIMIENTO
      ac.indestadotransferencia   IN ('C','N') AND
      ac.codcuenta = c.codcuenta AND    
      ac.mesdevengue = c.mesdevengueinicial and      
      ac.cuspp in (
'619950LGAIO8',
'598480CARRS9',
'232771LBESI0',
'610290EBDAI3',
'326560YHCYD1')
and ta.Codgrupotipoaporte='OBL'
order by
e.ruc,
c.cuspp,
c.codcuenta,
ac.mesdevengue
;

-- QUERY LIZ 

SELECT c.id_nss          cuspp,
       c.cod_cuenta      codcuenta,      
       c.tipo_afiliacion,     
       e.ruc,       
       c.num_mes_devengue_ini,
       ac.mesdevengue,
       ac.fecpago,
       ac.fecacreditacion
  FROM udwhods.ud_acreditacioncic ac LEFT JOIN md_empleador e ON e.codempleador = ac.codempleador,
       udwhstg.td_fo_cuentas c LEFT JOIN udwhstg.td_ca_solicitud cs ON cs.seq_formulario = c.num_contrato
                               LEFT JOIN udwhstg.td_tr_solicitud ts ON ts.seq_formulario = c.num_contrato_tra,
       udwhods.md_persona pf,
       md_destipoaporte ta
 WHERE ac.fecpago between '31-MAR-2017' and '01-ABR-2017' AND --SE CAMBIA       
       ac.fecacreditacion > '31-MAR-2018'      AND --SE CAMBIA    -- ac.fecacreditacion <  '3-sep-2014'      AND	
	   ac.codtransaccion IN ('1A01','1A50') AND --APORTE, REZAGO LOP_TRANSACCIONMOVIMIENTO   
       ac.codcuenta       =  c.cod_cuenta      AND
       ac.mesdevengue     >= c.num_mes_devengue_ini AND
       c.cod_cuenta       <> '0'           AND
       c.cod_cliente      =  pf.codpersona     AND		   
       ac.tipaporte       =  ta.tipaporte      AND              
    -- ac.tipaporte       = '5101'        AND
       ta.codgrupotipoaporte = 'OBL'      AND       
       NOT EXISTS        (SELECT * 
                            FROM udwhods.ud_acreditacioncic ace,
                                 udwhstg.td_fo_cuentas ce,
                                 md_destipoaporte tae
                           WHERE ace.codcuenta    =  ce.cod_cuenta   AND
                                 ace.tipaporte    =  tae.tipaporte    AND                                 
                                 ace.mesdevengue  >= ce.num_mes_devengue_ini AND
								 ace.codcuenta    =  c.cod_cuenta    AND
                                 ace.fecacreditacion < ac.fecacreditacion AND
                              -- ace.tipaporte =  '5101'          AND
                                 tae.codgrupotipoaporte = 'OBL'      AND
                                 ace.codtransaccion IN ('1A01','1A50') AND
                                 ace.indestadotransferencia IN ('C','N')
                          )--BUSCAR REGISTROS ANTERIORES PARAR
);


--**************** Query con funcion

select PRIMER_DEVENGUE.* 
FROM 
(SELECT -- hace el count en 20 min
       row_number() over(partition by e.ruc,c.id_nss,c.cod_cuenta order by e.ruc,c.id_nss,c.cod_cuenta,ac.mesdevengue ASC) as num_fila,
       e.ruc,
       c.id_nss          cuspp,
       c.cod_cuenta      cuenta,       
       c.tipo_afiliacion,      
       c.num_mes_devengue_ini,
       ac.mesdevengue,       
       ac.fecpago,
       ac.fecacreditacion,
       ac.tipmovimiento,
       ac.codtransaccion,
       ac.mtoacreditadosol,
       ac.ctdcuotas,
       ac.mtoramsol
       
  FROM udwhods.ud_acreditacioncic ac LEFT JOIN md_empleador e ON e.codempleador = ac.codempleador,
       udwhstg.td_fo_cuentas c LEFT JOIN udwhstg.td_ca_solicitud cs ON cs.seq_formulario = c.num_contrato
                               LEFT JOIN udwhstg.td_tr_solicitud ts ON ts.seq_formulario = c.num_contrato_tra,
       udwhods.md_persona pf,
       md_destipoaporte ta
 WHERE ac.fecpago  between TO_DATE('01/01/2018') AND  TO_DATE('30/04/2018')  AND 
       ac.fecacreditacion > TO_DATE ('31/03/2018') AND 
       ac.codtransaccion IN ('1A01','1A50') AND 
       ac.indestadotransferencia   IN ('C','N') AND       
       ac.codcuenta       =  c.cod_cuenta      AND
       ac.mesdevengue     >= c.num_mes_devengue_ini AND
       ac.cuspp ='502351CAMAU1' and
       c.cod_cuenta       <> '0'           AND
       c.cod_cliente      =  pf.codpersona     AND       
       ac.tipaporte       =  ta.tipaporte      AND              
    -- ac.tipaporte       = '5101'        AND
       ta.codgrupotipoaporte = 'OBL'   AND          
       NOT EXISTS        (SELECT * 
                            FROM udwhods.ud_acreditacioncic ace,
                                 udwhstg.td_fo_cuentas ce,
                                 md_destipoaporte tae
                           WHERE ace.codcuenta    =  ce.cod_cuenta   AND
                                 ace.tipaporte    =  tae.tipaporte    AND                                 
                                 ace.mesdevengue  >= ce.num_mes_devengue_ini AND
                                 ace.codcuenta    =  c.cod_cuenta    AND
                                 ace.fecacreditacion < ac.fecacreditacion AND
                              -- ace.tipaporte =  '5101'          AND
                                 tae.codgrupotipoaporte = 'OBL'      AND
                                 ace.codtransaccion IN ('1A01','1A50') AND
                                 ace.indestadotransferencia IN ('C','N')
                          )
  )PRIMER_DEVENGUE
WHERE 
NUM_FILA=1  ; 