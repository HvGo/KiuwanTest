SELECT 
                CPL.RUC,
                DPL.CUSPP,
                DPL.CODCUENTA,    
                C.TIPFORMULARIO,   
                CPL.MESDEVENGUE,
                C.MESDEVENGUEINICIAL,
                --*** TIPO DE DEVENGUE     
                CASE WHEN (CPL.MESDEVENGUE = C.MESDEVENGUEINICIAL) THEN 'S'
                     ELSE 'N'
                END ESPRIMERDEVENGUEOBL,  
                COUNT(CPL.NUMPLANILLA) CANTPLANILLAS, 
                MAX(DPL.CODNOVEDAD) CODNOVEDAD,                
                --*** INDICADORES
                SUM(DPL.MTORAMSOL) as MTORAMSOL,
                SUM(DPL.MTOTOTALFONDO) MTOTOTALFONDO,
                SUM(DPL.MTOSEGURO) MTOSEGURO,
                SUM(DPL.MTOCOMISION) MTOCOMISION,
                SUM(DPL.MTOTOTALADMINISTRADORA) MTOTOTALADMINISTRADORA,  
                SUM(DPL.MONTOTFONDOPGDO) MONTOTFONDOPGDO,
                SUM(DPL.MTOSEGUROPGDO) MTOSEGUROPGDO,
                SUM(DPL.MTOCOMISIONPGDO) MTOCOMISIONPGDO,
                SUM(DPL.MONTOTFONDOIPGDO) MONTOTFONDOIPGDO,
                SUM(DPL.MTOSEGUROIPGDO) MTOSEGUROIPGDO,
                SUM(DPL.MTOCOMISIONIPGDO)MTOCOMISIONIPGDO
              FROM 
                 UDWHODS.UD_PLANILLADETALLE DPL,
                 UDWHODS.UD_PLANILLA CPL, 
                 UDWHODS.md_cuenta c       
              WHERE        
                       DPL.CODESTADODETALLE ='ACR' AND
                       DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
                       CPL.NUMSEQPLANILLADET = 0 AND 
                       CPL.TIPPLANILLA IN ('001','002','008','009') AND  --APORTES Y REZAGOS    
                       CPL.FECACREDITACION BETWEEN TO_DATE('01/04/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                       CPL.FECPAGOPLANILLA BETWEEN TO_DATE('01/04/2018','dd/mm/yyyy') AND TO_DATE ('30/04/2018','dd/mm/yyyy') AND 
                       CPL.CODESTADOPLANILLA = 'ACR' AND
                       CPL.MESDEVENGUE = '201803' AND                                
                       DPL.CODCUENTA = C.CODCUENTA   
               GROUP BY
                      CPL.RUC,
                      DPL.CUSPP,
                      DPL.CODCUENTA,   
                      C.TIPFORMULARIO,         
                      CPL.MESDEVENGUE,
                      C.MESDEVENGUEINICIAL,    
                      CASE WHEN (CPL.MESDEVENGUE = C.MESDEVENGUEINICIAL) THEN 'S'
                           ELSE 'N'
                      END 