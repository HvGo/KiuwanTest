SELECT
       TO_CHAR(A.FECPAGO,'YYYYMM') MES_PAGO,
     A.MESDEVENGUE PER_DEV,       
     A.TIPAPORTE COD_TIPSALDO,
       dta.destipaporte,
       CASE 
         WHEN A.MESDEVENGUE = TO_CHAR(ADD_MONTHS(A.FECPAGO,-1),'YYYYMM') THEN SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 1, 0)) 
       END ABONOS_MESACTUAL, 
       CASE
          WHEN A.MESDEVENGUE < TO_CHAR(ADD_MONTHS(A.FECPAGO,-1),'YYYYMM') THEN SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 1, 0)) 
       END ABONOS_MESANTERIOR,
       CASE
         WHEN A.MESDEVENGUE > TO_CHAR(ADD_MONTHS(A.FECPAGO,-1),'YYYYMM') THEN SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 1, 0)) 
       END ABONOS_MESADELANTADO,      
       SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 1, 0)) AS ABONOS,
       SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 0, -1)) AS CARGOS,
       SUM(A.MTOACREDITADOSOL * decode(tipmovimiento, 10, 1, -1)) AS SOLES
      
FROM   UD_ACREDITACIONADM A,
  md_destipoaporte dta
WHERE           
         A.FECACREDITACION BETWEEN '01/MAY/2017' AND '31/MAY/2017'
  AND    A.CODCUENTA >'0'
  AND    A.CODESTADOACREDITACION = 'I'
  AND     a.tipaporte = dta.tipaporte
GROUP BY 
  
 TO_CHAR(A.FECPAGO,'YYYYMM'),
 TO_CHAR(A.FECACREDITACION,'YYYYMM'), 
 A.MESDEVENGUE,
 A.TIPAPORTE,
 dta.destipaporte,
 A.FECPAGO
 ORDER BY MES_PAGO, PER_DEV,COD_TIPSALDO
 