SELECT COUNT(*)

FROM (

SELECT    
                row_number() over(partition by CPL.RUC,DPL.CUSPP,CPL.MESDEVENGUE order by  CPL.RUC,DPL.CUSPP,CPL.MESDEVENGUE,DPL.MONTOTFONDOPGDO ASC) as NROLINEA,               
                TO_CHAR(CPL.FECACREDITACION,'YYYYMM') AS ANOMESACREDITACION, --SERVIRA DE LLAVE CON LA TABLA AGREADA  
                CPL.CODEMPLEADOR,
                CPL.RUC,
                DPL.CUSPP,
                DPL.CODCUENTA ,
                DPL.CODPERSONA,  
                CPL.NUMPLANILLA,                
                DPL.NUMSEQPLANILLA,
                DPL.NUMSEQPLANILLADET,    
                CPL.CODMEDIOCARGAPLANILLA,
                MCP.DESMEDIOCARGAPLANILLA,
                C.TIPFORMULARIO,
                CPL.FECREGISTRO,
                CPL.FECPAGOPLANILLA,
                CPL.FECACREDITACION,
                CPL.MESDEVENGUE,
                C.MESDEVENGUEINICIAL,
                --*** TIPO DE DEVENGUE     
                CASE WHEN (CPL.MESDEVENGUE = C.MESDEVENGUEINICIAL) THEN 'S'
                     ELSE 'N'
                END ESPRIMERDEVENGUEOBL,                   
                CPL.TIPPLANILLA,
                TPL.DESTIPPLANILLA,
                CPL.CODESTADOPLANILLA,
                EPL.DESESTADOPLANILLA,
                CPL.CODESTADOCONCILIACION,
                DPL.CODNOVEDAD,
                NOV.DESNOVEDAD,
                --*** INDICADORES
                DPL.MTORAMSOL,
                DPL.MTOTOTALFONDO,
                DPL.MTOSEGURO,
                DPL.MTOCOMISION,
                DPL.MTOTOTALADMINISTRADORA,  
                DPL.MONTOTFONDOPGDO,
                DPL.MTOSEGUROPGDO,
                DPL.MTOCOMISIONPGDO,
                DPL.MONTOTFONDOIPGDO,
                DPL.MTOSEGUROIPGDO,
                DPL.MTOCOMISIONIPGDO
              FROM 
                 UDWHODS.UD_PLANILLADETALLE DPL,
                 UDWHODS.UD_PLANILLA CPL, 
                 UDWHODS.md_cuenta c, 
                 UDWHODS.MD_DESESTADOPLANILLA EPL,
                 UDWHODS.MD_DESTIPOPLANILLA TPL,
                 UDWHODS.MD_DESMEDIOCARGAPLANILLA MCP,
                 UDWHODS.MD_DESNOVEDAD NOV        
              WHERE        
                 DPL.CODESTADODETALLE ='ACR' AND
                 DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
                 CPL.NUMSEQPLANILLADET = 0 AND 
                 CPL.TIPPLANILLA IN ('001','008','009') AND  --APORTES Y REZAGOS    
                 CPL.FECACREDITACION BETWEEN TO_DATE('01/04/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                 CPL.FECPAGOPLANILLA BETWEEN TO_DATE('01/04/2018','dd/mm/yyyy') AND TO_DATE ('30/04/2018','dd/mm/yyyy') AND 
                 CPL.CODESTADOPLANILLA = 'ACR' AND
                 CPL.MESDEVENGUE = '201803' AND   
                /* DPL.CUSPP IN  ('559141DQCSD3',
                                '497591ACCPT7',
                                '582700MCATO8',
                                '220830TTKOA9') AND*/
                 DPL.CODCUENTA = C.CODCUENTA AND
                 CPL.CODESTADOPLANILLA = EPL.CODESTADOPLANILLA AND
                 CPL.TIPPLANILLA = TPL.TIPPLANILLA(+) AND 
                 CPL.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
                 DPL.CODNOVEDAD = NOV.CODNOVEDAD(+)  
                 
                 
                 ) PLANILLAS WHERE NROLINEA =1
