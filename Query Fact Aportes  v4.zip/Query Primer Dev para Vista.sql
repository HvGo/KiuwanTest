SELECT PRIMER_DEV.*
FROM
  (SELECT -- hace el count en 20 min
         e.ruc,
         c.id_nss          cuspp,
         c.cod_cuenta      codcuenta,       
         c.tipo_afiliacion,      
         c.num_mes_devengue_ini mesdevengueini,
         ac.mesdevengue,       
         ac.fecpago,
         ac.fecacreditacion,
         CASE WHEN ac.mesdevengue = c.num_mes_devengue_ini THEN 1
         END ESDEVENGUEOBL,
         ac.tipmovimiento,
         ac.codtransaccion,
         ac.mtoacreditadosol,
         ac.ctdcuotas,
         ac.mtoramsol,       
         LAG(ac.mesdevengue,1,1) OVER (PARTITION BY e.ruc,c.id_nss,c.cod_cuenta ORDER BY e.ruc,c.id_nss,c.cod_cuenta,ac.fecpago,ac.mesdevengue) AS PRIMER_DEV,
         TA.DESTIPAPORTE
         
    FROM udwhods.ud_acreditacioncic ac LEFT JOIN md_empleador e ON e.codempleador = ac.codempleador,
         udwhstg.td_fo_cuentas c LEFT JOIN udwhstg.td_ca_solicitud cs ON cs.seq_formulario = c.num_contrato
                                 LEFT JOIN udwhstg.td_tr_solicitud ts ON ts.seq_formulario = c.num_contrato_tra,
         md_destipoaporte ta
   WHERE ac.codcuenta       =  c.cod_cuenta      AND
         c.cod_cuenta       <> '0'           AND
         ac.codtransaccion IN ('1A01','1A50') AND 
         ac.indestadotransferencia   IN ('C','N') AND      
         ac.tipaporte       =  ta.tipaporte      AND     
         ta.codgrupotipoaporte = 'OBL' )PRIMER_DEV
 WHERE PRIMER_DEV ='1' OR ESDEVENGUEOBL='1' ;