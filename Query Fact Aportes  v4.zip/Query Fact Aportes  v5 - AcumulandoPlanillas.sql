
SELECT 

--COUNT(*)
  PLANILLAS.ANOMESACREDITACION,
  PLANILLAS.RUC,
  PLANILLAS.CUSPP,
  PLANILLAS.CODCUENTA,  
  PLANILLAS.MESDEVENGUE,
  C.MESDEVENGUEINICIAL,
  PLANILLAS.TIPPLANILLA,
  TPL.DESTIPPLANILLA,                                                                                      
  PLANILLAS.CODNOVEDAD,
  NOV.DESNOVEDAD,
  C.TIPFORMULARIO,
  C.CODAFPFUSION,
  C.CODAFPORIGEN,
  PLANILLAS.CODESTADOPLANILLA,
  EPL.DESESTADOPLANILLA,
  PLANILLAS.CODESTADOCONCILIACION,
  PLANILLAS.CANTPLANILLAS,   
  PLANILLAS.CODMEDIOCARGAPLANILLA,  
  MCP.DESMEDIOCARGAPLANILLA,  
  -- EFICIENCIA DE PAGO                
    CASE 
         WHEN 
         (PLANILLAS.MESDEVENGUE = TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'DEL PERIODO'
         WHEN 
         (PLANILLAS.MESDEVENGUE <  TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'ATRASADO'  
         WHEN 
         (PLANILLAS.MESDEVENGUE >  TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'ADELANTADO'   
    END EFICIENCIAPAGO,
    --*** TIPO DE DEVENGUE     
    CASE WHEN (PLANILLAS.MESDEVENGUE = C.MESDEVENGUEINICIAL) THEN 'S'
         ELSE 'N'
    END ESPRIMERDEVENGUEOBL,   
     CASE 
         WHEN (PLANILLAS.MESDEVENGUE = C.MESDEVENGUEINICIAL) AND 
              (PLANILLAS.MESDEVENGUE = TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'FLUJO'
         WHEN PLANILLAS.MESDEVENGUE > C.MESDEVENGUEINICIAL AND 
              (PLANILLAS.MESDEVENGUE <= TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'STOCK' 
         WHEN (PLANILLAS.MESDEVENGUE = C.MESDEVENGUEINICIAL) AND  
              (PLANILLAS.MESDEVENGUE <  TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'STOCK FLUJO'   
         WHEN (PLANILLAS.MESDEVENGUE >  TO_CHAR(ADD_MONTHS(TO_DATE(PLANILLAS.ANOMESACREDITACION,'YYYYMM'),-1),'YYYYMM')) THEN 'ADELANTADO'  
         ELSE 'NO CLAS'
    END TIPDEVENGUE    ,
    -----INDICADORES--------
    PLANILLAS.MTORAMSOL,
    PLANILLAS.MTOTOTALFONDO,
    PLANILLAS.MTOSEGURO,
    PLANILLAS.MTOCOMISION,
    PLANILLAS.MTOTOTALADMINISTRADORA,  
    PLANILLAS.MONTOTFONDOPGDO,
    PLANILLAS.MTOSEGUROPGDO,
    PLANILLAS.MTOCOMISIONPGDO ,
    PLANILLAS.MONTOTFONDOIPGDO,
    PLANILLAS.MTOSEGUROIPGDO,
    PLANILLAS.MTOCOMISIONIPGDO
FROM (


                                    SELECT
                                      TO_CHAR(CPL.FECACREDITACION,'YYYYMM') AS ANOMESACREDITACION,  
                                      CPL.RUC,
                                      DPL.CUSPP,
                                      DPL.CODCUENTA,
                                      CPL.MESDEVENGUE,
                                      CPL.CODESTADOPLANILLA,
                                      CPL.CODESTADOCONCILIACION,
                                      COUNT(CPL.NUMPLANILLA) CANTPLANILLAS,   
                                      MAX(CPL.CODMEDIOCARGAPLANILLA) CODMEDIOCARGAPLANILLA,   
                                      MAX(CPL.TIPPLANILLA) TIPPLANILLA,                                                                                      
                                      MAX(DPL.CODNOVEDAD) CODNOVEDAD,                
                                      --*** INDICADORES
                                      SUM(DPL.MTORAMSOL) as MTORAMSOL,
                                      SUM(DPL.MTOTOTALFONDO) MTOTOTALFONDO,
                                      SUM(DPL.MTOSEGURO) MTOSEGURO,
                                      SUM(DPL.MTOCOMISION) MTOCOMISION,
                                      SUM(DPL.MTOTOTALADMINISTRADORA) MTOTOTALADMINISTRADORA,  
                                      SUM(DPL.MONTOTFONDOPGDO) MONTOTFONDOPGDO,
                                      SUM(DPL.MTOSEGUROPGDO) MTOSEGUROPGDO,
                                      SUM(DPL.MTOCOMISIONPGDO) MTOCOMISIONPGDO ,
                                      SUM(DPL.MONTOTFONDOIPGDO) MONTOTFONDOIPGDO,
                                      SUM(DPL.MTOSEGUROIPGDO) MTOSEGUROIPGDO,
                                      SUM(DPL.MTOCOMISIONIPGDO) MTOCOMISIONIPGDO
                                    FROM 
                                       UDWHODS.UD_PLANILLADETALLE DPL,
                                       UDWHODS.UD_PLANILLA CPL 
                                    WHERE        
                                       DPL.CODESTADODETALLE ='ACR' AND
                                       DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
                                       CPL.NUMSEQPLANILLADET = 0 AND 
                                       CPL.TIPPLANILLA NOT IN ('005','006') AND  --APORTES Y REZAGOS    
                                       /*CPL.TIPPLANILLA  IN ('001','008','009') AND  --APORTES Y REZAGOS   
                                       CPL.FECACREDITACION BETWEEN TO_DATE('01/05/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                                       CPL.FECPAGOPLANILLA BETWEEN TO_DATE('01/05/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                                       CPL.MESDEVENGUE = '201804' AND 
                                         */                                     
                                       CPL.FECACREDITACION BETWEEN TO_DATE('01/05/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                                       CPL.CODESTADOPLANILLA = 'ACR'
                                    GROUP BY  
                                        TO_CHAR(CPL.FECACREDITACION,'YYYYMM'),                  
                                        CPL.RUC,
                                        DPL.CUSPP,
                                        DPL.CODCUENTA,
                                        CPL.MESDEVENGUE,
                                        CPL.CODESTADOPLANILLA,
                                        CPL.CODESTADOCONCILIACION
                 
                 ) PLANILLAS ,
                 UDWHODS.MD_CUENTA C, 
                 UDWHODS.MD_DESESTADOPLANILLA EPL,
                 UDWHODS.MD_DESTIPOPLANILLA TPL,
                 UDWHODS.MD_DESMEDIOCARGAPLANILLA MCP,
                 UDWHODS.MD_DESNOVEDAD NOV
WHERE 
     PLANILLAS.CODCUENTA = C.CODCUENTA AND
     PLANILLAS.CODESTADOPLANILLA = EPL.CODESTADOPLANILLA AND
     PLANILLAS.TIPPLANILLA = TPL.TIPPLANILLA(+) AND 
     PLANILLAS.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
     PLANILLAS.CODNOVEDAD = NOV.CODNOVEDAD(+)                  

