SELECT 
--COUNT(*)
*
FROM (
SELECT    
                row_number() over(partition by CPL.RUC,DPL.CUSPP,CPL.TIPPLANILLA,CPL.MESDEVENGUE order by  CPL.RUC,DPL.CUSPP,CPL.MESDEVENGUE,DPL.MONTOTFONDOPGDO DESC) as NROLINEA,               
                TO_CHAR(CPL.FECACREDITACION,'YYYYMM') AS ANOMESACREDITACION, --SERVIRA DE LLAVE CON LA TABLA AGREADA
                CPL.CODEMPLEADOR,
                CPL.RUC,
                DPL.CUSPP,
                DPL.CODCUENTA,
                DPL.CODPERSONA,  
                CPL.NUMPLANILLA,                
                DPL.NUMSEQPLANILLA,
                DPL.NUMSEQPLANILLADET,    
                CPL.CODMEDIOCARGAPLANILLA,
                MCP.DESMEDIOCARGAPLANILLA,
                C.TIPFORMULARIO,
                C.CODAFPFUSION,
                C.CODAFPORIGEN,
                CPL.FECREGISTRO,
                CPL.FECPAGOPLANILLA,
                CPL.FECACREDITACION,
                CPL.MESDEVENGUE,
                C.MESDEVENGUEINICIAL,                
                --*** EFICIENCIA DE PAGO                
                CASE 
                     WHEN 
                     (CPL.MESDEVENGUE = TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION,-1),'YYYYMM')) THEN 'DEL PERIODO'
                     WHEN 
                     (CPL.MESDEVENGUE <  TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION,-1),'YYYYMM')) THEN 'ATRASADO'  
                     WHEN 
                     (CPL.MESDEVENGUE >  TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION, -1),'YYYYMM')) THEN 'ADELANTADO'   
                END EFICIENCIAPAGO,
                --*** TIPO DE DEVENGUE     
                CASE WHEN (CPL.MESDEVENGUE = C.MESDEVENGUEINICIAL) THEN 'S'
                     ELSE 'N'
                END ESPRIMERDEVENGUEOBL,   
                CASE 
                     WHEN --(CPL.MESDEVENGUE = C.NUM_MES_DEVENGUE_INI) AND 
                     (CPL.MESDEVENGUE = TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION,-1),'YYYYMM')) THEN 'FLUJO'
                     WHEN CPL.MESDEVENGUE > C.MESDEVENGUEINICIAL AND -- A pesar de que liz indico que no deberia ir es necesario para que no se confunda con los Stocks flujos
                     (CPL.MESDEVENGUE <  TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION,-1),'YYYYMM')) THEN 'STOCK'  
                     WHEN --CPL.MESDEVENGUE > C.NUM_MES_DEVENGUE_INI AND
                     (CPL.MESDEVENGUE >  TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION, -1),'YYYYMM')) THEN 'STOCK ADELANTADO'    
                     WHEN  (CPL.MESDEVENGUE = C.MESDEVENGUEINICIAL) AND  
                     (CPL.MESDEVENGUE <  TO_CHAR(ADD_MONTHS(CPL.FECACREDITACION,-1),'YYYYMM')) THEN 'STOCK FLUJO'    
                     ELSE 'NO CLAS'
                END TIPDEVENGUE,                
                CPL.TIPPLANILLA,
                TPL.DESTIPPLANILLA,
                CPL.CODESTADOPLANILLA,
                EPL.DESESTADOPLANILLA,
                CPL.CODESTADOCONCILIACION,
                DPL.CODNOVEDAD,
                NOV.DESNOVEDAD,                              
                --*** INDICADORES 
                DPL.MTORAMSOL,
                DPL.MTOTOTALFONDO,
                DPL.MTOSEGURO,
                DPL.MTOCOMISION,
                DPL.MTOTOTALADMINISTRADORA,  
                DPL.MONTOTFONDOPGDO,
                DPL.MTOSEGUROPGDO,
                DPL.MTOCOMISIONPGDO,
                DPL.MONTOTFONDOIPGDO,
                DPL.MTOSEGUROIPGDO,
                DPL.MTOCOMISIONIPGDO
              FROM 
                 UDWHODS.UD_PLANILLADETALLE DPL,
                 UDWHODS.UD_PLANILLA CPL, 
                 UDWHODS.md_cuenta c, 
                 UDWHODS.MD_DESESTADOPLANILLA EPL,
                 UDWHODS.MD_DESTIPOPLANILLA TPL,
                 UDWHODS.MD_DESMEDIOCARGAPLANILLA MCP,
                 UDWHODS.MD_DESNOVEDAD NOV         
              WHERE        
                 DPL.CODESTADODETALLE ='ACR' AND
                 DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
                 CPL.NUMSEQPLANILLADET = 0 AND 
                 CPL.TIPPLANILLA NOT IN ('005','006') AND  --APORTES Y REZAGOS    
                 CPL.FECACREDITACION BETWEEN TO_DATE('01/05/2018','dd/mm/yyyy') AND TO_DATE ('31/05/2018','dd/mm/yyyy') AND 
                 CPL.CODESTADOPLANILLA = 'ACR' AND
                 DPL.CODCUENTA = C.CODCUENTA AND
                 CPL.CODESTADOPLANILLA = EPL.CODESTADOPLANILLA AND
                 CPL.TIPPLANILLA = TPL.TIPPLANILLA(+) AND 
                 CPL.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
                 DPL.CODNOVEDAD = NOV.CODNOVEDAD(+) 
) DETALLE_PLANILLAS WHERE NROLINEA =1