create or replace procedure udwhods.p_ud_mstcompingresos(p_periodo varchar2 default null) is
  V_PERIODO   BINARY_INTEGER; 
  V_DEVENGUE  BINARY_INTEGER; 
  V_FECPAGINI DATE; 
  V_FECPAGFIN DATE; 
  V_FECACRINI DATE; 
  V_FECACRFIN DATE; 
  v_DIASADIC  BINARY_INTEGER:=3; 
BEGIN 
  select nvl(p_periodo,codmes) into v_periodo from md_fechacarga; 
 
  SELECT 
      TO_CHAR(ADD_MONTHS(TO_DATE(V_PERIODO,'YYYYMM'),-1),'YYYYMM'), 
      TO_DATE(V_PERIODO,'YYYYMM'), 
      LAST_DAY(TO_DATE(V_PERIODO,'YYYYMM')), 
      TO_DATE(V_PERIODO,'YYYYMM'), 
      LAST_DAY(TO_DATE(V_PERIODO,'YYYYMM'))+v_DIASADIC 
          INTO 
          V_DEVENGUE, 
          V_FECPAGINI, 
          V_FECPAGFIN, 
          V_FECACRINI, 
          V_FECACRFIN 
     FROM DUAL; 
      
  execute immediate 'truncate table TMP_PLANILLASCLASEPAGOS_1'; 
  execute immediate 'truncate table TMP_PLANILLASCLASEPAGOS_2'; 
 
  INSERT INTO TMP_PLANILLASCLASEPAGOS_1 
  ( 
          PERIODO, 
          DEVENGUE, 
          CODEMPLEADOR, 
          CUSPP, 
          CODCUENTA, 
          TIPPLANILLA, 
          FECPAGO, 
          FECACRE, 
          MTORAM, 
          MTOFDO, 
          MTOADM, 
          MTOCOM, 
          DEVENGUEINICIAL, 
          TIPFORMULARIO 
  ) 
     SELECT 
          V_PERIODO, 
          P.MESDEVENGUE, 
          P.CODEMPLEADOR, 
          PD.CUSPP, 
          PD.CODCUENTA, 
          p.tipplanilla, 
          max(p.fecpagoplanilla), 
          max(p.fecacreditacion), 
          sum(pd.mtoramsol), 
          sum(pd.mtototalfondo), 
          sum(pd.mtototaladministradora), 
          sum(nvl(pd.mtocomision,0)+nvl(pd.mtocomisionfija,0)), 
          C.MESDEVENGUEINICIAL, 
          c.tipformulario 
     FROM  
			   UDWHODS.UD_PLANILLA P 
               JOIN UDWHODS.MD_DESTIPOPLANILLA TP ON TP.TIPPLANILLA=P.TIPPLANILLA 
               JOIN UDWHODS.UD_PLANILLADETALLE PD ON PD.NUMSEQPLANILLA=P.NUMSEQPLANILLA 
               JOIN UDWHODS.MD_CUENTA C ON C.CODCUENTA=PD.CODCUENTA 
               LEFT JOIN 
                    ( 
                         SELECT  
                              R.SEQ_PLANILLA,  
                              R.SEQ_DETALLE,  
                              max(R.FEC_SALIDA) FEC_SALIDA  
                         FROM   
                              td_re_rezago R  
                         WHERE  
                              R.COD_ESTADO_REZAGO='ACR'  
                         GROUP BY  
                              R.SEQ_PLANILLA,  
                              R.SEQ_DETALLE                
                    )RP ON RP.SEQ_PLANILLA = PD.NUMSEQPLANILLA  AND RP.SEQ_DETALLE=PD.NUMSEQPLANILLADET 
 
     WHERE 
          P.CODESTADOPLANILLA='ACR' AND 
          PD.CODESTADODETALLE='ACR' AND 
          P.FECPAGOPLANILLA>=V_FECPAGINI AND 
          P.FECPAGOPLANILLA<=V_FECPAGFIN AND 
          P.FECACREDITACION>=V_FECACRINI AND 
          P.FECACREDITACION<=V_FECACRFIN AND 
          P.TIPPLANILLA IN ('001','002','008','009','010') AND 
          ( 
            (RP.FEC_SALIDA IS NULL) OR 
               (RP.FEC_SALIDA <= V_FECACRFIN) 
    )                
  group by 
          P.MESDEVENGUE, 
          P.CODEMPLEADOR, 
          PD.CUSPP, 
          PD.CODCUENTA, 
          p.tipplanilla, 
          C.MESDEVENGUEINICIAL, 
          c.tipformulario; 
 
  commit; 
      
  INSERT INTO TMP_PLANILLASCLASEPAGOS_2 
  ( 
          PERIODO, 
          DEVENGUE, 
          CODEMPLEADOR, 
          CUSPP, 
          CODCUENTA, 
          TIPPLANILLA, 
          FECPAGO, 
          FECACRE, 
          MTORAM, 
          MTOFDO, 
          MTOADM, 
          MTOCOM, 
          DEVENGUEINICIAL, 
          TIPFORMULARIO, 
          CTDAPORTE 
  ) 
     SELECT 
          p1.PERIODO, 
          p1.DEVENGUE, 
          p1.CODEMPLEADOR, 
          p1.CUSPP, 
          p1.CODCUENTA, 
          p1.tipplanilla, 
          p1.FECPAGO, 
          p1.FECACRE, 
          p1.MTORAM, 
          p1.MTOFDO, 
          p1.MTOADM, 
          p1.MTOCOM, 
          p1.DEVENGUEINICIAL, 
          p1.TIPFORMULARIO, 
          count(distinct cic.mesdevengue) 
     FROM  
          TMP_PLANILLASCLASEPAGOS_1 p1 
               JOIN udwhods.ud_acreditacioncic cic on cic.codcuenta=p1.codcuenta 
     WHERE 
          cic.codtransaccion in ('1A01','1A50') and 
          cic.indestadotransferencia in ('C','N') and 
          cic.mesdevengue<=v_devengue and 
          cic.fecacreditacion<=V_FECACRFIN 
  group by 
          p1.PERIODO, 
          p1.DEVENGUE, 
          p1.CODEMPLEADOR, 
          p1.CUSPP, 
          p1.CODCUENTA, 
          p1.tipplanilla, 
          p1.FECPAGO, 
          p1.FECACRE, 
          p1.MTORAM, 
          p1.MTOFDO, 
          p1.MTOADM, 
          p1.MTOCOM, 
          p1.DEVENGUEINICIAL, 
          p1.TIPFORMULARIO; 
     commit; 
 
     UPDATE TMP_PLANILLASCLASEPAGOS_2 t 
     SET CLASE=null 
     where periodo=v_periodo; 
     commit; 
 
 
     UPDATE TMP_PLANILLASCLASEPAGOS_2 t 
     SET CLASE='F' 
     where  
          t.devengue=t.devengueinicial and  
          t.devengue=V_DEVENGUE and 
          periodo=v_periodo; 
     commit; 
 
     UPDATE TMP_PLANILLASCLASEPAGOS_2 t 
     SET CLASE='SF' 
     where  
          t.devengueinicial<>t.devengue and  
          t.ctdaporte=1 and 
          periodo=v_periodo; 
     commit; 
 
     UPDATE TMP_PLANILLASCLASEPAGOS_2 t 
     SET CLASE='S' 
     where  
          clase is null and 
          periodo=v_periodo; 
     commit; 
 
  delete from ud_mstcompingresos where periodo=v_periodo; 
      
     insert into ud_mstcompingresos 
     ( 
          tiptrabajador, 
          tipformulario, 
          periodo, 
          TIPODEVENGUE, 
          clase, 
          mtoram, 
          mtofdo, 
          mtocom, 
          mtoadm, 
          ctd, 
          mtoramprom, 
          fecdia 
     ) 
     select 
          tiptrabajador, 
          tipformulario, 
          periodo, 
          TIPODEVENGUE, 
          clase, 
          sum(mtoram)mtoram, 
          sum(mtofdo)mtofdo, 
          sum(mtocom)mtocom, 
          sum(mtoadm)mtoadm, 
          count(1) ctd, 
          avg(mtoram)mtoramprom, 
          sysdate fecdia 
     from 
          ( 
          select 
               t.cuspp, 
               t.tipformulario, 
               case  
                    when TIPPLANILLA IN ('001','002','008','009') then 'D'   
                    when TIPPLANILLA IN ('010') then 'I'  
               end tiptrabajador, 
               t.periodo, 
               case  
                    when V_DEVENGUE=devengue then 'M' 
                    when V_DEVENGUE<devengue then 'MP' 
                    when V_DEVENGUE>devengue then 'MF' 
               end TIPODEVENGUE, 
               t.clase, 
               sum(t.mtoram)mtoram, 
               sum(t.mtofdo)mtofdo, 
               sum(t.mtocom)mtocom, 
               sum(t.mtoadm)mtoadm 
          from 
               TMP_PLANILLASCLASEPAGOS_2 t 
          group by 
               t.cuspp, 
               t.tipformulario, 
               case  
                    when TIPPLANILLA IN ('001','002','008','009') then 'D'   
                    when TIPPLANILLA IN ('010') then 'I'  
               end, 
               t.periodo, 
               case  
                    when V_DEVENGUE=devengue then 'M' 
                    when V_DEVENGUE<devengue then 'MP' 
                    when V_DEVENGUE>devengue then 'MF' 
               end, 
               t.clase                     
          ) 
     group by 
          tiptrabajador, 
    tipformulario, 
          periodo, 
          TIPODEVENGUE, 
          clase; 
 
end p_ud_mstcompingresos;
