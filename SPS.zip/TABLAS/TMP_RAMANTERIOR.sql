-- Create table
create table UDWHODS.TMP_RAMANTERIOR
(
  ruc                    VARCHAR2(30),
  cuspp                  VARCHAR2(12),
  codcuenta              VARCHAR2(15),
  tipformulario          CHAR(1),
  mesdevengue            NUMBER,
  mesdevengueinicial     NUMBER,
  esprimerdevengueobl    CHAR(1),
  cantplanillas          NUMBER,
  codnovedad             VARCHAR2(5),
  mtoramsol              NUMBER,
  mtototalfondo          NUMBER,
  mtoseguro              NUMBER,
  mtocomision            NUMBER,
  mtototaladministradora NUMBER,
  montotfondopgdo        NUMBER,
  mtoseguropgdo          NUMBER,
  mtocomisionpgdo        NUMBER,
  montotfondoipgdo       NUMBER,
  mtoseguroipgdo         NUMBER,
  mtocomisionipgdo       NUMBER
 )  nologging  pctfree 0 parallel  tablespace USRODS_DATA;
CREATE INDEX TMP_RAMANTERIOR_N01 --FUNGE COMO PK
ON UDWHODS.TMP_RAMANTERIOR (RUC,CUSPP,CODCUENTA,TIPFORMULARIO,MESDEVENGUE,MESDEVENGUEINICIAL,ESPRIMERDEVENGUEOBL) nologging pctfree 0 parallel tablespace USRODS_IND;
