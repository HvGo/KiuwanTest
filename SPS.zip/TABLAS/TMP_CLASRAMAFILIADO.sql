create table UDWHODS.TMP_CLASRAMAFILIADO
(
  mesdevanalisis         NUMBER,
  ruc                    VARCHAR2(30),
  cuspp                  VARCHAR2(12),
  mtoram_analisis        NUMBER,
  codnovedad_analiis     VARCHAR2(5),
  tipformulario_analisis CHAR(1),
  cantplanillas          NUMBER,
  clasificacion          VARCHAR2(20),
  indaumentoram          NUMBER,
  inddisminuyeram        NUMBER,
  mesdevengue_ant        NUMBER,
  mtoram_ant             NUMBER,
  codnovedad_ant         VARCHAR2(5),
  tipformulario_ant      CHAR(1),
  cantplanillas_ant      NUMBER
) nologging tablespace USRODS_DATA;



select * from dba_tablespaces
