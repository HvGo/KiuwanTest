-- Create table
create table UDWHODS.TMP_DEPRESUMENINGRESOS
(
  mesacreditacion        NUMBER,
  codmediocargaplanilla  CHAR(1),
  desmediocargaplanilla  VARCHAR2(50),
  tipformulario          CHAR(1),
  eficienciapago         VARCHAR2(25),
  tipdevengue            VARCHAR2(25),
  tipplanilla            VARCHAR2(3),
  destipplanilla         VARCHAR2(80),
  codestadoplanilla      VARCHAR2(3),
  desestadoplanilla      VARCHAR2(50),
  codnovedad             VARCHAR2(2),
  desnovedad             VARCHAR2(80),
  desclasificacionram    VARCHAR2(50),
  esprimerdevengueobl    CHAR(1),
  mesdevengue            NUMBER,
  mesdevclasiram         NUMBER,
  cntcuentas             INTEGER,
  cntplanillas           INTEGER,
  mtoramsol              NUMBER,
  mtoaumentoram          NUMBER,
  mtodisminuyoram        NUMBER,
  mtototalfondo          NUMBER,
  mtoseguro              NUMBER,
  mtocomision            NUMBER,
  mtototaladministradora NUMBER,
  mtotfondopgdo          NUMBER,
  mtoseguropgdo          NUMBER,
  mtocomisionpgdo        NUMBER,
  mtotfondoipgdo         NUMBER,
  mtoseguroipgdo         NUMBER,
  mtocomisionipgdo       NUMBER
)  nologging  pctfree 0 parallel  tablespace USRODS_DATA;
CREATE INDEX TMP_DEPRESUMENINGRESOS_N01 --FUNGE COMO PK
ON UDWHODS.TMP_DEPRESUMENINGRESOS(MESACREDITACION,CODMEDIOCARGAPLANILLA,TIPDEVENGUE,TIPPLANILLA,CODESTADOPLANILLA,CODNOVEDAD,DESCLASIFICACIONRAM,ESPRIMERDEVENGUEOBL) nologging pctfree 0 parallel tablespace USRODS_IND;

CREATE INDEX TMP_DEPRESUMENINGRESOS_N02
ON UDWHODS.TMP_DEPRESUMENINGRESOS( MESACREDITACION,TIPPLANILLA,CODNOVEDAD,DESCLASIFICACIONRAM,TIPDEVENGUE ) nologging pctfree 0 parallel tablespace USRODS_IND;

CREATE INDEX TMP_DEPRESUMENINGRESOS_N03
ON UDWHODS.TMP_DEPRESUMENINGRESOS( MESACREDITACION ) nologging pctfree 0 parallel tablespace USRODS_IND;

