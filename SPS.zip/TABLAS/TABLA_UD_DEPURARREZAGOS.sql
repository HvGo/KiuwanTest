create table UDWHODS.UD_DEPREZAGOS
(
  periodo                          VARCHAR2(6) ,
  fecingreso                       DATE,
  fectransferencia                 DATE,
  codrazonrezago                   VARCHAR2(5) not null,
  codentidaddestinorezago          VARCHAR2(3),
  tipcuentadeposito                VARCHAR2(2),
  idacreditacionrezago             NUMBER not null,
  codtransaccionmovimiento         VARCHAR2(5),
  codsuborigenacreditacion         VARCHAR2(5),
  codestadorezago                  VARCHAR2(5),
  codafporigen                     VARCHAR2(2),
  fec_caja                         DATE,
  mon_rezago_fondo                 NUMBER,
  mon_rezago_afp                   NUMBER,
  com_flujo                        NUMBER,
  com_mixta                        NUMBER
) nologging tablespace USRODS_DATA;
CREATE INDEX UD_DEPREZAGOS_N01 
ON UDWHODS.UD_DEPREZAGOS (periodo) pctfree 0 parallel nologging tablespace USRODS_IND;
