create table UDWHODS.UD_DETALLEAPORTES
(
  nrolinea               NUMBER,
  anomesacreditacion     VARCHAR2(6),
  codempleador           VARCHAR2(15),
  ruc                    VARCHAR2(30),
  cuspp                  VARCHAR2(12),
  codcuenta              VARCHAR2(15),
  codpersona             VARCHAR2(15),
  numplanilla            VARCHAR2(35),
  numseqplanilla         NUMBER not null,
  numseqplanilladet      NUMBER not null,
  codmediocargaplanilla  CHAR(1),
  desmediocargaplanilla  VARCHAR2(50),
  tipformulario          CHAR(1),
  codafpfusion           VARCHAR2(2),
  codafporigen           VARCHAR2(2),
  fecregistro            DATE,
  fecpagoplanilla        DATE,
  fecacreditacion        DATE,
  mesdevengue            NUMBER,
  mesdevengueinicial     NUMBER,
  eficienciapago         VARCHAR2(11),
  esprimerdevengueobl    CHAR(1),
  tipdevengue            VARCHAR2(11),
  tipplanilla            VARCHAR2(3),
  destipplanilla         VARCHAR2(80),
  codestadoplanilla      VARCHAR2(3),
  desestadoplanilla      VARCHAR2(50),
  codestadoconciliacion  VARCHAR2(5),
  codnovedad             VARCHAR2(5),
  desnovedad             VARCHAR2(80),
  mtoramsol              NUMBER(18,2),
  mtototalfondo          NUMBER,
  mtoseguro              NUMBER,
  mtocomision            NUMBER,
  mtototaladministradora NUMBER,
  montotfondopgdo        NUMBER(20,8),
  mtoseguropgdo          NUMBER(20,8),
  mtocomisionpgdo        NUMBER(20,8),
  montotfondoipgdo       NUMBER(20,8),
  mtoseguroipgdo         NUMBER(20,8),
  mtocomisionipgdo       NUMBER(20,8)
)  nologging tablespace USRODS_DATA;
CREATE INDEX UD_DETALLEAPORTES_N01 
ON UDWHODS.UD_DETALLEAPORTES (anomesacreditacion,codempleador,ruc, cuspp) nologging pctfree 0 parallel  tablespace USRODS_IND;

CREATE INDEX UD_DETALLEAPORTES_N02 
ON UDWHODS.UD_DETALLEAPORTES (anomesacreditacion) nologging pctfree 0 parallel  tablespace USRODS_IND;

CREATE INDEX UD_DETALLEAPORTES_N03
ON UDWHODS.UD_DETALLEAPORTES (codempleador) nologging pctfree 0 parallel  tablespace USRODS_IND;

CREATE INDEX UD_DETALLEAPORTES_N04 
ON UDWHODS.UD_DETALLEAPORTES (ruc) nologging pctfree 0 parallel  tablespace USRODS_IND;

CREATE INDEX UD_DETALLEAPORTES_N05
ON UDWHODS.UD_DETALLEAPORTES (cuspp) nologging pctfree 0 parallel  tablespace USRODS_IND;


