SELECT /*+INDEX(d UD_ACREDITACIONCIC_N03) */
           M.CODMESACUMANIO CodMes,
          SUM(
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5101' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5102' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5201' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5202' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5203' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)) as MtoTotalPlanilla
FROM 
          UD_Acreditacioncic d, 
          UD_Planilla P,
          LTM_mesacumanio M
WHERE
          D.nummovimiento = P.Nummovimto
          AND TO_CHAR(D.fecacreditacion,'YYYYMM') =M.Codmesacumanio
          AND TO_CHAR(D.fecpago,'YYYYMM') =M.Codmesacumanio
          AND P.Codestadoplanilla IN ('ACR', 'REC') 
          AND D.codorigenacreditacion = 4 
          AND d.codsuborigenacreditacion ='1'
          AND D.Codestadoacreditacioncic IN ('I','A') 
          AND M.Codmes=(SELECT CODMESANT FROM MD_FechaCarga)
GROUP BY 
           M.CODMESACUMANIO      
UNION ALL					  
SELECT /*+INDEX(d UD_ACREDITACIONCIC_N03) */
           M.CODMESACUMANIO CodMes,
          SUM(
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5101' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5102' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5201' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5202' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)+
          DECODE(D.CODCUENTA,'0', 0, CASE WHEN D.TIPAPORTE = '5203' AND D.CODESTADOACREDITACIONCIC = 'A' THEN D.MTOACREDITADOSOL ELSE 0 END)) as MtoTotalPlanilla
FROM 
          UD_Acreditacioncic d, 
          UD_Planilla P,
          LTM_mesacumanio M
WHERE
          D.nummovimiento=P.Nummovimtoafp
          AND TO_CHAR(D.fecacreditacion,'YYYYMM') =M.Codmesacumanio
          AND TO_CHAR(D.fecpago,'YYYYMM') =M.Codmesacumanio
          AND P.Codestadoplanilla IN ('ACR', 'REC') 
          AND D.codorigenacreditacion = 4 
          AND d.codsuborigenacreditacion ='1'
          AND D.Codestadoacreditacioncic IN ('I','A') 
          AND M.Codmes=(SELECT CODMESANT FROM MD_FechaCarga)
GROUP BY 
           M.CODMESACUMANIO   				
