select	[Actividad Econ�mica_O45]@[DESACTIVIDADECONOMICA_O45],
	[Departamento]@[CustCol_35],
	[Departamento]@[DESDEPARTAMENTOSUNAT],
	[Empleador]@[CODEMPLEADOR],
	[Empleador]@[RUC],
	[Empleador]@[RAZONSOCIAL],
	[Empresa Sector]@[DESEMPRESASECTOR],
	[Mes Acreditacion]@[CODMESACREDITACION],
	[Mes Acreditacion]@[DESMESACREDITACION],
	[Mes Devengue]@[CODMESDEVENGUE],
	[Mes Devengue]@[DESMESDEVENGUE],
	[Rango Ram]@[CODRANGORAM],
	[Rango Ram]@[DESRANGORAM],
	[Regi�n]@[DESREGION],
	sum([Monto RAM])@{[Empleador],[Mes Acreditacion],[Mes Devengue],[Rango Ram]},
	sum([Cotizantes])@{[Empleador],[Mes Acreditacion],[Mes Devengue],[Rango Ram]}
from	Cubo Operaciones
where	([Mes Acreditacion]@[CODMESACREDITACION] = [Mes Pago Planilla]@[CODMESPAGOPLANILLA]
 and [Tipo Devengue]@[TIPDEVENGUE] in (DEVENGUE DEL PERIODO))