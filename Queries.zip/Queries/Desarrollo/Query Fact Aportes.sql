--Query de Fact aportes

     
select --2.11
    CPL.codempleador,
    CPL.codmediocargaplanilla,
    MCP.DESMEDIOCARGAPLANILLA,
    CPL.fecregistro,
    CPL.fecpagoplanilla,
    CPL.fecacreditacion,
    CPL.mesdevengue,
    CPL.tipplanilla,
    TPL.DESTIPPLANILLA,
    CPL.codestadoplanilla,
    EPL.DESESTADOPLANILLA,
    CPL.codestadoconciliacion,
    --***
    DPL.cuspp,
    DPL.codcuenta,
    DPL.codpersona,
    DPL.codnovedad,
    NOV.DESNOVEDAD,
    DPL.mtototalfondo,
    DPL.mtoseguro,
    DPL.mtocomision,
    DPL.mtototaladministradora,
    DPL.mtoramsol,
    DPL.montotfondopgdo,
    DPL.mtoseguropgdo,
    DPL.mtocomisionpgdo,
    DPL.montotfondoipgdo,
    DPL.mtoseguroipgdo,
    DPL.mtocomisionipgdo,
    DPL.mtoobligatorioafililiado,
    DPL.mtoobligatorioempleador,
    DPL.mtototalobligatorio,
    DPL.mtovoluntarioafiliadocf,
    DPL.mtovolultarioafiliadosf,
    DPL.mtovoluntarioempleadorcf,
    DPL.mtocts,
    DPL.mtoaporteipss,
    DPL.mtocomisionfija
      
from 
     UD_PLANILLADETALLE DPL,
     UD_PLANILLA CPL,    
     LOP_ESTADOPLANILLA EPL,
     LOP_TIPOPLANILLA TPL,
     LOP_MEDIOCARGAPLANILLA MCP,
     UDWHODS.MD_DESNOVEDAD NOV
where DPL.CODESTADODETALLE ='ACR' AND
      DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND
      DPL.CODESTADODETALLE = CPL.codestadoplanilla AND
	    CPL.NUMSEQPLANILLADET=0 AND 
	    CPL.TIPPLANILLA NOT IN ('005','006') AND
      CPL.CODESTADOPLANILLA =EPL.CODESTADOPLANILLA AND
      CPL.TIPPLANILLA=TPL.TIPPLANILLA AND 
      CPL.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
      DPL.CODNOVEDAD = NOV.CODNOVEDAD(+)
	  
	  
--PRIMER DEVENGUE
 LAG(DPL.NUMSEQPLANILLADET) OVER (PARTITION BY DPL.CODCUENTA ORDER BY DPL.NUMSEQPLANILLA, DPL.NUMSEQPLANILLADET) AS PRIMER_DEV  	  




--Query con el calculo del  primer devengue para todo el universo de pagos    
  
select --13.19 EN MOSTRAR LOS REGISTROS CANTIDAD DE REGISTROS PARA ABRIL 864628
--COUNT(*)
    DPL.NUMSEQPLANILLA,
    DPL.NUMSEQPLANILLADET,
    CPL.codempleador,
    CPL.codmediocargaplanilla,
    MCP.DESMEDIOCARGAPLANILLA,
    CPL.fecregistro,
    CPL.fecpagoplanilla,
    CPL.fecacreditacion,
    CPL.mesdevengue,
    CPL.tipplanilla,
    TPL.DESTIPPLANILLA,
    CPL.codestadoplanilla,
    EPL.DESESTADOPLANILLA,
    CPL.codestadoconciliacion,
    --***
    DPL.cuspp,
    DPL.codcuenta,
    DPL.codpersona,
    DPL.codnovedad,
    NOV.DESNOVEDAD,
    DPL.mtototalfondo,
    DPL.mtoseguro,
    DPL.mtocomision,
    DPL.mtototaladministradora,
    DPL.mtoramsol,
    DPL.montotfondopgdo,
    DPL.mtoseguropgdo,
    DPL.mtocomisionpgdo,
    DPL.montotfondoipgdo,
    DPL.mtoseguroipgdo,
    DPL.mtocomisionipgdo,
    DPL.mtoobligatorioafililiado,
    DPL.mtoobligatorioempleador,
    DPL.mtototalobligatorio,
    DPL.mtovoluntarioafiliadocf,
    DPL.mtovolultarioafiliadosf,
    DPL.mtovoluntarioempleadorcf,
    DPL.mtocts,
    DPL.mtoaporteipss,
    DPL.mtocomisionfija
    ,DECODE(LAG(DPL.NUMSEQPLANILLADET) OVER (PARTITION BY DPL.CODCUENTA ORDER BY DPL.NUMSEQPLANILLA, DPL.NUMSEQPLANILLADET),NULL,'PRIMER DEV',NULL) AS PRIMER_DEV
from 
     UD_PLANILLADETALLE DPL,
     UD_PLANILLA CPL,    
     LOP_ESTADOPLANILLA EPL,
     LOP_TIPOPLANILLA TPL,
     LOP_MEDIOCARGAPLANILLA MCP,
     UDWHODS.MD_DESNOVEDAD NOV
where DPL.CODESTADODETALLE ='ACR' AND
      DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
      CPL.NUMSEQPLANILLADET=0 AND 
      CPL.TIPPLANILLA NOT IN ('005','006') AND      
    --CPL.FECACREDITACION BETWEEN TO_DATE('01/04/2018') AND TO_DATE ('30/04/2018') AND 
      CPL.codestadoplanilla = 'ACR' AND
      CPL.CODESTADOPLANILLA =EPL.CODESTADOPLANILLA AND
      CPL.TIPPLANILLA=TPL.TIPPLANILLA AND 
      CPL.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
      DPL.CODNOVEDAD = NOV.CODNOVEDAD(+)
	  
	  
	  
	  --***********************************************************************
	  
	  
	  select --13.19 EN MOSTRAR LOS REGISTROS CANTIDAD DE REGISTROS PARA ABRIL 864628
--COUNT(*)
    DPL.NUMSEQPLANILLA,
    DPL.NUMSEQPLANILLADET,
    CPL.codempleador,
    CPL.codmediocargaplanilla,
    MCP.DESMEDIOCARGAPLANILLA,
    CPL.fecregistro,
    CPL.fecpagoplanilla,
    CPL.fecacreditacion,
    CPL.mesdevengue,
    CPL.tipplanilla,
    TPL.DESTIPPLANILLA,
    CPL.codestadoplanilla,
    EPL.DESESTADOPLANILLA,
    CPL.codestadoconciliacion,
    --***
    DPL.cuspp,
    DPL.codcuenta,
    DPL.codpersona,
    DPL.codnovedad,
    NOV.DESNOVEDAD,
    DPL.mtototalfondo,
    DPL.mtoseguro,
    DPL.mtocomision,
    DPL.mtototaladministradora,
    DPL.mtoramsol,
    DPL.montotfondopgdo,
    DPL.mtoseguropgdo,
    DPL.mtocomisionpgdo,
    DPL.montotfondoipgdo,
    DPL.mtoseguroipgdo,
    DPL.mtocomisionipgdo,
    DPL.mtoobligatorioafililiado,
    DPL.mtoobligatorioempleador,
    DPL.mtototalobligatorio,
    DPL.mtovoluntarioafiliadocf,
    DPL.mtovolultarioafiliadosf,
    DPL.mtovoluntarioempleadorcf,
    DPL.mtocts,
    DPL.mtoaporteipss,
    DPL.mtocomisionfija,
    PRIMER_DEV.PRIMER_DEV
   
from 
     UD_PLANILLADETALLE DPL,
     UD_PLANILLA CPL,    
     LOP_ESTADOPLANILLA EPL,
     LOP_TIPOPLANILLA TPL,
     LOP_MEDIOCARGAPLANILLA MCP,
     UDWHODS.MD_DESNOVEDAD NOV,
     --*******
     (select --13.19 EN MOSTRAR LOS REGISTROS CANTIDAD DE REGISTROS PARA ABRIL 864628
         DPL.NUMSEQPLANILLA,
         DPL.NUMSEQPLANILLADET,
         CPL.MESDEVENGUE,
         DPL.CODCUENTA,
         DECODE(LAG(DPL.NUMSEQPLANILLADET) OVER (PARTITION BY DPL.CODCUENTA ORDER BY DPL.NUMSEQPLANILLA, DPL.NUMSEQPLANILLADET),NULL,'PRIMER DEV',NULL) AS PRIMER_DEV            
        from 
             UD_PLANILLADETALLE DPL,
             UD_PLANILLA CPL
        where DPL.CODESTADODETALLE ='ACR' AND
              DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
              CPL.NUMSEQPLANILLADET=0 AND 
              CPL.TIPPLANILLA NOT IN ('005','006') AND   
              CPL.codestadoplanilla = 'ACR') PRIMER_DEV 
       
where DPL.CODESTADODETALLE ='ACR' AND
      DPL.NUMSEQPLANILLA = CPL.NUMSEQPLANILLA AND      
      CPL.NUMSEQPLANILLADET=0 AND 
      CPL.TIPPLANILLA NOT IN ('005','006') AND      
      CPL.FECACREDITACION BETWEEN TO_DATE('01/04/2018') AND TO_DATE ('30/04/2018') AND 
      CPL.codestadoplanilla = 'ACR' AND
      CPL.CODESTADOPLANILLA =EPL.CODESTADOPLANILLA AND
      CPL.TIPPLANILLA=TPL.TIPPLANILLA AND 
      CPL.CODMEDIOCARGAPLANILLA = MCP.CODMEDIOCARGAPLANILLA(+) AND
      DPL.CODNOVEDAD = NOV.CODNOVEDAD(+)       
      --************************
      AND DPL.NUMSEQPLANILLADET = PRIMER_DEV.NUMSEQPLANILLADET AND
      DPL.NUMSEQPLANILLA = PRIMER_DEV.NUMSEQPLANILLA
      
	  
	  
	  
	  
	  
	  
	  
	  
	  