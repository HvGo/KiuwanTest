SQL Statements:

Pass0 - 	Query Execution:	0:01:42.55
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.07
create table TD1J7T819MD000 nologging as
select	a11.CODRANGORAM  CODRANGORAM,
	a12.CODMESACREDITACION  CODMESACREDITACION,
	sum(a11.MTORAMSOL)  MONTORAM,
	count(a11.CUSPP)  COTIZANTES
from	UDWHBDS.F_DETPLANILLA	a11
	join	UDWHBDS.LTM_DIAACREDITACION	a12
	  on 	(a11.FECACREDITACION = a12.CODDIAACREDITACION)
	join	UDWHBDS.LTM_DIAPAGOPLANILLAOP	a13
	  on 	(a11.FECPAGOPLANILLA = a13.CODDIAPAGOPLANILLA)
where	(a12.CODMESACREDITACION = a13.CODMESPAGOPLANILLA
 and a11.TIPDEVENGUE in ('DEVENGUE DEL PERIODO'))
group by	a11.CODRANGORAM,
	a12.CODMESACREDITACION 

Pass1 - 	Query Execution:	0:00:00.04
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.04
create index TD1J7T819MD000_i on TD1J7T819MD000 (CODRANGORAM, CODMESACREDITACION) 

Pass2 - 	Query Execution:	0:00:00.07
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
create table T4F9PTP25MD001 nologging as
select	pa11.CODRANGORAM  CODRANGORAM,
	a12.CODMES  CODMESACREDITACION,
	NVL((sum(pa11.MONTORAM) / 12.0), 0)  MONTORAMPROMEDIO,
	sum(pa11.COTIZANTES)  COTIZANTESACUM12
from	TD1J7T819MD000	pa11
	join	UDWHBDS.LTM_MESACUMANIO	a12
	  on 	(pa11.CODMESACREDITACION = a12.CODMESACUMANIO)
where	((a12.CODMES)
 in	(select	s21.CODMESACREDITACION
	from	UDWHBDS.LTM_MESACREDITACION	s21
		cross join	UDWHBDS.LTM_MESPAGOPLANILLAOP	s22
	where	s21.CODMESACREDITACION = s22.CODMESPAGOPLANILLA))
group by	pa11.CODRANGORAM,
	a12.CODMES 

Pass3 - 	Query Execution:	0:00:00.00
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
create index T4F9PTP25MD001_i on T4F9PTP25MD001 (CODRANGORAM, CODMESACREDITACION) 

Pass4 - 	Query Execution:	0:00:00.01
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
create table TOT5TRHN7OJ002 nologging as
select	pa11.CODRANGORAM  CODRANGORAM,
	pa11.CODMESACREDITACION  CODMESACREDITACION
from	TD1J7T819MD000	pa11 

Pass5 - 	Query Execution:	0:00:00.00
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
insert into TOT5TRHN7OJ002 
select	pa11.CODRANGORAM  CODRANGORAM,
	pa11.CODMESACREDITACION  CODMESACREDITACION
from	T4F9PTP25MD001	pa11

Pass6 - 	Query Execution:	0:00:00.00
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
create table TZV3NRDW3OD003 nologging as
select	distinct pa11.CODRANGORAM  CODRANGORAM,
	pa11.CODMESACREDITACION  CODMESACREDITACION
from	TOT5TRHN7OJ002	pa11 

Pass7 - 	Query Execution:	0:00:00.01
	Data Fetching and Processing:	0:00:00.00
	  Data Transfer from Datasource(s):	0:00:00.00
	Other Processing:	0:00:00.03
create index TZV3NRDW3OD003_i on TZV3NRDW3OD003 (CODRANGORAM, CODMESACREDITACION) 

Pass8 - 	Query Execution:	0:00:00.01
	Data Fetching and Processing:	0:00:00.03
	  Data Transfer from Datasource(s):	0:00:00.01
	Other Processing:	0:00:00.03
	Rows selected: 600
select	pa11.CODMESACREDITACION  CODMESACREDITACION,
	a16.DESMESACREDITACION  DESMESACREDITACION,
	pa11.CODRANGORAM  CODRANGORAM,
	a17.DESRANGORAM  DESRANGORAM,
	pa12.MONTORAMPROMEDIO  MONTORAMPROMEDIO,
	pa13.MONTORAM  MONTORAM,
	pa13.COTIZANTES  COTIZANTES,
	pa12.COTIZANTESACUM12  COTIZANTESACUM12
from	TZV3NRDW3OD003	pa11
	left outer join	T4F9PTP25MD001	pa12
	  on 	(pa11.CODMESACREDITACION = pa12.CODMESACREDITACION and 
	pa11.CODRANGORAM = pa12.CODRANGORAM)
	left outer join	TD1J7T819MD000	pa13
	  on 	(pa11.CODMESACREDITACION = pa13.CODMESACREDITACION and 
	pa11.CODRANGORAM = pa13.CODRANGORAM)
	join	UDWHBDS.LTM_MESACREDITACION	a16
	  on 	(pa11.CODMESACREDITACION = a16.CODMESACREDITACION)
	join	UDWHBDS.LAF_RANGORAM	a17
	  on 	(pa11.CODRANGORAM = a17.CODRANGORAM)