/*
truncate table procesos_control;
select * from procesos_control for update;

select * from procesos_carga;
*/

select * from log_carga_tablas where fecha_actualizacion  is not null order by fecha_actualizacion desc;

select * from td_fo_movimtos
select * from td_fo_movimtos_deta;
select * from td_fo_cuentas;
select * from td_personas;




grant execute on udwhstg.log_cargas to udwhods;
grant execute on udwhstg.log_cargas to udwhbds;

create synonym udwhods.log_cargas for udwhstg.log_cargas;
create synonym udwhbds.log_cargas for udwhstg.log_cargas;



alter table udwhstg.td_personas move tablespace UDWHSTG_P1_DATA;

alter table udwhods.GTT_VP_FEC_EMI move tablespace UDWHSTG_P1_DATA;
alter table udwhods.GTT_VP_SBS_MON move tablespace UDWHSTG_P1_DATA;
alter table udwhods.GTT_VP_VAL move tablespace UDWHSTG_P1_DATA;
alter table udwhods.UD_VECTORPRECIOS move tablespace UDWHSTG_P1_DATA;

alter table udwhods.UD_VALORCUOTA move tablespace UDWHSTG_P1_DATA;
alter table udwhods.AUX_VALORCUOTA move tablespace UDWHSTG_P1_DATA;

gtt_titulos_maximos

select * from all_tables where owner = 'UDWHODS';


-- ejecutar en produccion

SELECT proceso || ';', pc.* FROM procesos_carga pc 
 WHERE estado IN ('V')  and periodicidad in ('D','S')
 ORDER BY flujo, esquema desc, ORDEn , duracion desc, fecha_inicio 


select * from dba_tablespaces where tablespace_name like 'UDWHS%DATA%'

alter table udwhstg.td_re_detalle_planilla move tablespace UDWHSTG_G1_DATA;
alter table udwhstg.td_cb_gestion_detalle move tablespace UDWHSTG_G2_DATA;
alter table udwhstg.td_fo_movimtos_deta move tablespace UDWHSTG_G2_DATA;

